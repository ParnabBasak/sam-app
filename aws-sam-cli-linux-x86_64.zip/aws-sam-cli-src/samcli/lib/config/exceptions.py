"""
Exceptions to be used by samconfig.py
"""


class SamConfigVersionException(Exception):
    pass
